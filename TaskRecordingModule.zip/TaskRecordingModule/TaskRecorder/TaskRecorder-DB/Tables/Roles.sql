﻿CREATE TABLE [dbo].[Roles]
(
	[RoleId] INT NOT NULL PRIMARY KEY Identity(1,1),
	[RoleName] NVARCHAR(max)
)
