﻿CREATE TABLE [dbo].[UserRoles]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[RoleId] INT,
	[UserId] NVARCHAR(max)
)
