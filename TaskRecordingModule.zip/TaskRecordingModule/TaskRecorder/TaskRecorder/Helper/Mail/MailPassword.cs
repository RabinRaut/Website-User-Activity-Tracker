﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TaskRecorder.Helper.Mail
{
    public class MailPassword
    {
        public static string MailpasswordHelper()
        {
            var pass = "rr2020RR";
            return pass.ToString();
        }
    }
}
